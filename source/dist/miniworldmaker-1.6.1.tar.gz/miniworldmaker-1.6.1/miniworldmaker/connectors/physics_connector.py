from miniworldmaker.connectors import pixel_connector


class PhysicsBoardConnector(pixel_connector.PixelBoardConnector):
    pass
